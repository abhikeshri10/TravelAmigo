from django.contrib import admin
from .models import fullUser,travel,state

# Register your models here.
admin.site.register(fullUser)
admin.site.register(travel)
admin.site.register(state)